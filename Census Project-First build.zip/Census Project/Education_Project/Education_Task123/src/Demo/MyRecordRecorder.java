package Demo;

import java.io.IOException;


import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;

public class MyRecordRecorder extends RecordReader<MyKey, MyValue> 
{

	MyKey key=new MyKey();
	MyValue value=new MyValue();
	LineRecordReader reader=new LineRecordReader();
	
	@Override
	public void close() throws IOException 
	{
		reader.close();
	}

	@Override
	public MyKey getCurrentKey() throws IOException, InterruptedException 
	{
		return key;
	}

	@Override
	public MyValue getCurrentValue() throws IOException, InterruptedException 
	{
		return value;
	}

	@Override
	public float getProgress() throws IOException, InterruptedException 
	{
		return reader.getProgress();
	}

	@Override
	public void initialize(InputSplit is, TaskAttemptContext tac) throws IOException, InterruptedException 
	{
		reader.initialize(is,tac);
	}

	@Override
	public boolean nextKeyValue() throws IOException, InterruptedException 
	{
		boolean gotNextKeyValue = reader.nextKeyValue();
		if(gotNextKeyValue)
		{
			if(key==null)
			{
				key = new MyKey();
			}
			if(value == null)
			{
				value = new MyValue();
			}
			Text line = reader.getCurrentValue();
			String[] tokens = line.toString().split(",");
			key.setAge(new Text(tokens[0]));
			value.setEducation(new Text(tokens[1]));
			value.setMaritalStatus(new Text(tokens[2]));
			value.setGender(new Text(tokens[3]));
			value.setTaxFilerStatus(new Text(tokens[4]));
			value.setIncome(new Text(tokens[5]));
			value.setParents(new Text(tokens[6]));
			value.setCountryOfBirth(new Text(tokens[7]));
			value.setCitizenship(new Text(tokens[8]));
			value.setWeeksWorked(new Text(tokens[9]));
		}
		else
		{
			key = null;
			value = null;
		}
		return gotNextKeyValue;	
	}

}
