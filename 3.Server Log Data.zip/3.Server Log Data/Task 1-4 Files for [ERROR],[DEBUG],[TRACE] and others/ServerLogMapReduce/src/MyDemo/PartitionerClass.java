package MyDemo;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class PartitionerClass extends Partitioner<Text,Text> 
{
	public int getPartition(Text mapkey,Text mapval,int number) 
	{
		if(mapkey.toString().equals("[ERROR]"))
			return 0;
			else if(mapkey.toString().equals("[DEBUG]"))
			return 1;
			else if(mapkey.toString().equals("[TRACE]"))
				return 2;
			else
			return 3;
	}
}
