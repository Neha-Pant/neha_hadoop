package MyDemo;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class ReducerClass extends Reducer<Text,IntWritable,Text,IntWritable>
{
public void reduce(Text inkey,Iterable<IntWritable> invals,Context context) throws InterruptedException, IOException
{
	int count=0;
	for(IntWritable data:invals)
	{
		count++;
	}
				context.write(new Text(inkey),new IntWritable(count));
    }
}