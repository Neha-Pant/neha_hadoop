package Demo;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;


public class CustomerClass implements Writable {

	public String name,profession;
	public int age;
	
	public CustomerClass() {
	name=" ";
	profession=" ";
	age=0;
	}
	
	public String toString()
	{
		return "| NAME : "+name+" | PROFESSION : "+profession+" | AGE : "+age+" |";
	}
	
	public CustomerClass(int a,String b,String c) 
	{
		name=b;
		profession=c;
		age=a;
	}

	@Override
	public void readFields(DataInput arg0) throws IOException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void write(DataOutput arg0) throws IOException {
		// TODO Auto-generated method stub
		
	}

}
