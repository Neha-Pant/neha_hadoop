package Demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<LongWritable,Text,Text,CustomerClass>
{
private Map<String,CustomerClass> map=new TreeMap<>();

@Override
protected void setup(Mapper<LongWritable, Text, Text, CustomerClass>.Context context)
		throws IOException, InterruptedException {
	BufferedReader br=new BufferedReader(new FileReader("/home/hduser/custs-large.dat"));
	String line="";
	while((line=br.readLine())!=null)
	{
		String data[]=line.split(",");
		String id=data[0];
		String name=data[1]+" "+data[2];
		Integer age=Integer.parseInt(data[3]);
		String profession=data[4];
		//String details=name+" "+age+" "+profession;
		CustomerClass ob=new CustomerClass(age,name,profession);
		map.put(id,ob);
	}
	br.close();
}

@Override
protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, CustomerClass>.Context context)
		throws IOException, InterruptedException {
	String[] tData=value.toString().split(",");
	String tid=tData[2];
	String tamount=tData[3];
	CustomerClass tDetails=map.get(tid);
	
//	String output=" ID : "+tid+" DETAILS : "+tdetails+" AMOUNT : "+tamount;
	
	context.write(new Text(tid+" "+tamount),tDetails);
}

//@Override
//protected void cleanup(Mapper<LongWritable, Text, Text, NullWritable>.Context context)
//		throws IOException, InterruptedException {
//	// TODO Auto-generated method stub
//	super.setup(context);
//}

}
