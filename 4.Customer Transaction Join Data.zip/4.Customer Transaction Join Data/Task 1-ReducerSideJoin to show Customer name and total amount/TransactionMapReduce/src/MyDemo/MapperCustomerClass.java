package MyDemo;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperCustomerClass extends Mapper<LongWritable, Text,Text,Text>
{
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
    {
    	String line=value.toString();
        String[] lineparts=line.split(",");
        String name="NAME:"+lineparts[1];
        String id="ID:"+lineparts[0];
      		  context.write(new Text(id),new Text(name));

      }
}