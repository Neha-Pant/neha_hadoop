package Demo;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;



public class CustomerClass implements Writable
{

	public Text name,profession,age;
	
	public Text getName() {
		return name;
	}

	public void setName(Text name) {
		this.name = name;
	}

	public Text getProfession() {
		return profession;
	}

	public void setProfession(Text profession) {
		this.profession = profession;
	}

	public Text getAge() {
		return age;
	}

	public void setAge(Text age) {
		this.age = age;
	}

	public CustomerClass() {
	name=new Text();
	profession=new Text();
	age=new Text();
	}
	
	public String toString()
	{
		return "NAME : "+name.toString()+" AGE : "+age.toString()+" PROFESSION : "+profession;
	}
	public CustomerClass(Text a,Text b,Text c) 
	{
		name=b;
		profession=c;
		age=a;
	}

	public void readFields(DataInput in) throws IOException {
				age.readFields(in);
				name.readFields(in);
				profession.readFields(in);
	}

	public void write(DataOutput out) throws IOException {
		age.write(out);
		name.write(out);
		profession.write(out);
	}

}
