package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CombinerClass extends Reducer<Text,CustomerClass,Text,CustomerClass> 
{
	public void reduce(Text inkey,Iterable<CustomerClass> invals,Context context) throws InterruptedException, IOException
	{
		int count=0;
		for(CustomerClass ob:invals)
	{
			if(count==0)
		 context.write(inkey,ob);
			count++;
		}
	}
}
