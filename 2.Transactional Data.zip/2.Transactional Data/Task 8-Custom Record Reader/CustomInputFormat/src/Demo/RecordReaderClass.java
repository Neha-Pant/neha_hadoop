package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.InputSplit;
import org.apache.hadoop.mapreduce.RecordReader;
import org.apache.hadoop.mapreduce.TaskAttemptContext;
import org.apache.hadoop.mapreduce.lib.input.LineRecordReader;

public class RecordReaderClass extends RecordReader<KeyClass,ValueClass> 
{
	private KeyClass key;
	private ValueClass value;
	private LineRecordReader reader=new LineRecordReader();
	
	@Override
	public void close() throws IOException {
		// TODO Auto-generated method stub
		reader.close();
	}

	@Override
	public KeyClass getCurrentKey() throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return key;
	}

	@Override
	public ValueClass getCurrentValue() throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return value;
	}

	@Override
	public float getProgress() throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return reader.getProgress();
	}

	@Override
	public void initialize(InputSplit sp, TaskAttemptContext at) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		reader.initialize(sp,at);
		
	}

	@Override
	public boolean nextKeyValue() throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		boolean gotNextKeyValue = reader.nextKeyValue();
		if(gotNextKeyValue){
			if(key==null){
				key = new KeyClass();
			}
			if(value == null){
				value = new ValueClass();
			}
			Text line = reader.getCurrentValue();
			String[] tokens = line.toString().split(",");
			
			key.setTid(new Text(tokens[0]));
			key.setTdate(new Text(tokens[1]));
			value.setUid(new Text(tokens[2]));
			value.setAmount(new Text(tokens[3]));
			value.setCategory(new Text(tokens[4]));
	}
	else
	{
		key = null;
		value = null;
	}
	return gotNextKeyValue;
	
	}
}

