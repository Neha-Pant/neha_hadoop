package Demo;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class DriverClass 
{
public static void main(String []arg) throws IOException, ClassNotFoundException, InterruptedException
{
	Configuration con=new Configuration();
	Job job=new Job(con,"Custom Input Format");
	job.setNumReduceTasks(0);
	job.setJarByClass(DriverClass.class);
	job.setMapSpeculativeExecution(true);
	job.setMapperClass(MapperClass.class);
	job.setInputFormatClass(FileInputFormatClass.class);
	job.setMapOutputKeyClass(Text.class);
	job.setMapOutputValueClass(Text.class);
	FileInputFormatClass.addInputPath(job,new Path(arg[0]));
	FileOutputFormat.setOutputPath(job,new Path(arg[1]));
	job.waitForCompletion(true);
}
}
