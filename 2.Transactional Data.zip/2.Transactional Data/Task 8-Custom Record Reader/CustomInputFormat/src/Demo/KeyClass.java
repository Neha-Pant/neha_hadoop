package Demo;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

@SuppressWarnings("rawtypes")
public class KeyClass implements WritableComparable
{
	private Text tid,tdate;
	
	public KeyClass(Text tid, Text tdate) {
		super();
		this.tid = tid;
		this.tdate = tdate;
	}

	public KeyClass() {
		// TODO Auto-generated constructor stub
		tid=new Text();
		tdate=new Text();
	}


	@Override
	public void readFields(DataInput in) throws IOException 
	{
	tid.readFields(in);
	tdate.readFields(in);	
	}

	@Override
	public void write(DataOutput out) throws IOException 
	{
	tid.write(out);
	tdate.write(out);
	}

	@Override
	public int compareTo(Object ob) 
	{
		KeyClass other = (KeyClass)ob;
		int cmp = tid.compareTo(other.tid);
		if(cmp != 0)
		{
				return cmp;
		}
		return cmp = tdate.compareTo(other.tdate);
	}

	public Text getTid() {
		return tid;
	}

	public void setTid(Text tid) {
		this.tid = tid;
	}

	public Text getTdate() {
		return tdate;
	}

	public void setTdate(Text tdate) {
		this.tdate = tdate;
	}
}