package Demo;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

@SuppressWarnings("rawtypes")
public class ValueClass implements WritableComparable
{
	private Text uid,amount,category;
	
	public ValueClass(Text uid, Text amount,Text category) 
	{
		super();
		this.uid = uid;
		this.amount = amount;
		this.category=category;
	}

	public ValueClass() {
		// TODO Auto-generated constructor stub
		uid=new Text();
		amount=new Text();
		category=new Text();
	}

	@Override
	public void readFields(DataInput in) throws IOException 
	{
	uid.readFields(in);
	amount.readFields(in);
	category.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException 
	{
	uid.write(out);
	amount.write(out);
	category.write(out);
	}

	@Override
	public int compareTo(Object ob) 
	{
		ValueClass other = (ValueClass)ob;
		int cmp = amount.compareTo(other.amount);
		if(cmp != 0){
				return cmp;
		}
		return category.compareTo(other.category);
	}

	public Text getUid() {
		return uid;
	}

	public void setUid(Text uid) {
		this.uid = uid;
	}

	public Text getAmount() {
		return amount;
	}

	public void setAmount(Text amount) {
		this.amount = amount;
	}

	public Text getCategory() {
		return category;
	}

	public void setCategory(Text category) {
		this.category = category;
	}
	public Double get10xAmount() {
		return Double.parseDouble(amount.toString())*10;
	}
}