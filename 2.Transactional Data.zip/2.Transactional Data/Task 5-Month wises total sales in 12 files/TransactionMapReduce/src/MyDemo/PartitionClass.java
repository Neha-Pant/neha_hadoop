package MyDemo;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class PartitionClass extends Partitioner<Text,DoubleWritable> 
{
	public int getPartition(Text mapkey,DoubleWritable mapval,int number) 
	{
		if(mapkey.toString().equals("01"))
			return 0;
			else if(mapkey.toString().equals("02"))
			return 1;
			else if(mapkey.toString().equals("03"))
				return 2;
			else if(mapkey.toString().equals("04"))
				return 3;
			else if(mapkey.toString().equals("05"))
				return 4;
			else if(mapkey.toString().equals("06"))
				return 5;
			else if(mapkey.toString().equals("07"))
				return 6;
			else if(mapkey.toString().equals("08"))
				return 7;
			else if(mapkey.toString().equals("09"))
				return 8;
			else if(mapkey.toString().equals("10"))
				return 9;
			else if(mapkey.toString().equals("11"))
				return 10;
			else
			return 11;
	}
}
