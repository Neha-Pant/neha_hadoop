package MyDemo;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class ReducerClass extends Reducer<Text,DoubleWritable,Text,DoubleWritable>
{
	public static final NavigableMap<Double,String> map=new TreeMap<>();
//protected void setup(Context context) throws IOException,InterruptedException
//{
//			
//}
public void reduce(Text inkey,Iterable<DoubleWritable> invals,Context context) throws InterruptedException, IOException
{
	 Double sum=new Double(0);
    for(DoubleWritable singleValue:invals)
    {
      sum+=singleValue.get();
    }
    //context.write(new Text(inkey),new DoubleWritable(sum));
    map.put(sum,inkey.toString());
    }	
protected void cleanup(Context context) throws IOException,InterruptedException
{ 
			Set<Double> ob=map.keySet();
			int count=0;
	for(Double a:ob)
	{
		if(count==(ob.size()-1))
		{
	context.write(new Text(map.get(a)),new DoubleWritable(a));
		}
		count++;
	}
}
}