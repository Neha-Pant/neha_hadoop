import java.io.IOException;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class ConcatClass extends EvalFunc<String> 
{

	@Override
	public String exec(Tuple arg0) throws IOException 
	{
	String[] data=arg0.toString().split(" ");
//here cud have used split(" ",5),HENCE LAST WHOLE PART WILL BE INSIDE THE 4TH INDEX,SO NO REQUIREMENT 
//OF this cud have accessed 4th index and access the nwhole info
	String msg=" ";
	int len=data.length;
	for(int i=4;i<len;i++)
	{
		msg+=data[i]+" ";
	}
	return msg;
	}

}
