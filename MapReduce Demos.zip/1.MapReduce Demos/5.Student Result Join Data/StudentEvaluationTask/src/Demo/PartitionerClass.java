package Demo;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class PartitionerClass extends Partitioner<Text,Text>
{
public int getPartition(Text key, Text value, int arg2)
{
	String status=key.toString();
	if(status.equals("pass"))
		return 0;
	else
		return 1;
}
}
