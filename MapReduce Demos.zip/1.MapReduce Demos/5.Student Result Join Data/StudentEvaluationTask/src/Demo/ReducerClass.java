package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerClass extends Reducer<Text,Text,Text,Text>
{
public void reduce(Text inkey,Iterable<Text> invals,Context context) throws InterruptedException, IOException
{
	for(Text ob:invals)
	context.write(ob,new Text(" . "));
}
}