package Demo;
import java.io.IOException;
import java.util.Set;
import java.util.TreeMap;
import java.util.Map;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class ReducerClass extends Reducer<Text,Text,Text,Text>
{
	Map<Integer,String> map=new TreeMap<Integer,String>();
	protected void reduce(Text key, Iterable<Text> val,Context context) throws IOException, InterruptedException 
	{
	int count=0;
	for(@SuppressWarnings("unused") Text a:val)
	{
		count++;
	}
	map.put(count, key.toString());
	//context.write(new Text(key),new Text(c));
	}
	@Override
	protected void cleanup(Context context) throws IOException, InterruptedException 
	{
		Set<Integer> ob=map.keySet();
		int len=map.size();
		int i=0;
	for(Integer a:ob)
	{
		if(i==(len-1))
		{
			String module=map.get(a);
			context.write(new Text(module),new Text(a.toString()));
		}
		i++;
	}
	}

}
