package Demo;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MapperClass extends Mapper<LongWritable,Text,Text,Text> 
{

	@Override
	protected void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException 
	{
		String Value=value.toString();
		String data[]=Value.split(" ");
		String type=data[3];
		String module=data[2];
		if(type.contains("[ERROR]"))
		{
		context.write(new Text(module),new Text(""));
		}
	}
}
