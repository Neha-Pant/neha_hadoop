package Demo;
import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class MapperClass extends Mapper<LongWritable,Text,Text,Text> 
{

	@Override
	protected void map(LongWritable key, Text value,Context context) throws IOException, InterruptedException 
	{
		String Value=value.toString();
		String data[]=Value.split(" ");
		String type=data[3];
		context.write(new Text(type),new Text(""));
	}
	

}
