package Demo;
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class DriverClass 
{
public static void main(String []arg) throws IOException, InterruptedException, ClassNotFoundException
{
	Configuration con=new Configuration();
	Job job=new Job(con,"Server Log Task 1");
	job.setMapperClass(MapperClass.class);
	job.setReducerClass(ReducerClass.class);
	job.setJarByClass(DriverClass.class);
	job.setNumReduceTasks(1);
	FileInputFormat.addInputPath(job,new Path(arg[0]));
	FileOutputFormat.setOutputPath(job,new Path(arg[1]));
	job.setMapOutputKeyClass(Text.class);
	job.setMapOutputValueClass(Text.class);
	System.exit(job.waitForCompletion(true)?0:1);
}
}
