package Demo;
import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<LongWritable,Text,Text,Text>
{
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text,Text>.Context context)
			throws IOException, InterruptedException 
	{
		String data[]=value.toString().split(",");
	int tyear=Integer.parseInt(data[2]);//year
		if((tyear>1945) && (tyear<1959))
		{
			context.write(new Text("->"), new Text(" "));
		}

	}
}

