package Demo;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class DriverClass 
{
public static void main(String []arg) throws IOException, ClassNotFoundException, InterruptedException
{
	Configuration con=new Configuration();
	Job job=new Job(con,"Movie evaluation demo");//throws IOException
	job.setJarByClass(DriverClass.class);
	job.setNumReduceTasks(1);
	job.setMapperClass(MapperClass.class);
	job.setReducerClass(ReducerClass.class);
	job.setMapOutputKeyClass(IntWritable.class);
	job.setMapOutputValueClass(Text.class);
	FileInputFormat.addInputPath(job, new Path(arg[0]));
	FileOutputFormat.setOutputPath(job,new Path(arg[1]));
	System.exit(job.waitForCompletion(true)?0:1);
}
}
