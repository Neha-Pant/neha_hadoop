package Demo;
import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<LongWritable,Text,IntWritable,Text>
{
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text,IntWritable,Text>.Context context)
			throws IOException, InterruptedException 
	{
		String data[]=value.toString().split(",");
		String tname=data[1];
	Integer tyear=Integer.parseInt(data[2]);//year
			context.write(new IntWritable(tyear), new Text(tname));
	}
}

