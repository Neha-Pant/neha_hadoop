package Demo;
import java.io.IOException;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<LongWritable,Text,Text,Text>
{
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text,Text>.Context context)
			throws IOException, InterruptedException 
	{
		String data[]=value.toString().split(",");
	float trating=Float.parseFloat(data[4]);//year
		if((trating>(1.5*60*60)))
		{
			context.write(new Text("->"), new Text(" "));
		}

	}
}

