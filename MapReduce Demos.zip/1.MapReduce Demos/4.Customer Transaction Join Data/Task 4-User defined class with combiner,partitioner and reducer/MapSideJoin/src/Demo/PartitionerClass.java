package Demo;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class PartitionerClass extends Partitioner<Text,CustomerClass> 
{
	@Override
	public int getPartition(Text key, CustomerClass value, int arg2) 
	{
		int d=Integer.parseInt(value.getAge().toString());
		if((d>19)&&(d<30))
		{
			return 0;
		}
		else if((d>29)&&(d<40))
		{
			return 1;
		}
		else if((d>39)&&(d<50))
		{
			return 2;
		}
		else if((d>49)&&(d<60))
		{
			return 3;
		}
		else if((d>59)&&(d<70))
		{
			return 4;
		}
		else
		{
			return 5;
		}	
	}
}
