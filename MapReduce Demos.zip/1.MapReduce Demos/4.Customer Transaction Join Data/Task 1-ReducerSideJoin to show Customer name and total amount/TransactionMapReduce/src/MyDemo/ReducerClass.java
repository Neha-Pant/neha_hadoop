package MyDemo;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class ReducerClass extends Reducer<Text,Text,Text,DoubleWritable>
{
public void reduce(Text inkey,Iterable<Text> invals,Context context) throws InterruptedException, IOException
{
    Double sum=new Double(0);
    String name = "";
    String id="";
    for(Text singleValue:invals)
    {
      String part[]=singleValue.toString().split(":");
      if(part[0].equals("AMT"))
      {
    	  sum+=Double.parseDouble(part[1]);
      }
      else if(part[0].equals("NAME"))
      {
    	  name=part[1];
      }
      else
      {
    	  
      }
    }
//    String data=inkey.toString()+" "+count+" "+sum.toString();
    context.write(new Text(name),new DoubleWritable(sum));
    }	
}