package MyDemo;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Partitioner;

public class PartionerClass extends Partitioner<Text,IntWritable>
{
	@Override
	public int getPartition(Text mapkey,IntWritable mapval,int number) 
	{
		if(mapkey.toString().toLowerCase().startsWith("d"))
			return 0;
			else if(mapkey.toString().toLowerCase().startsWith("t"))
			return 1;
			else
			return 2;
	}

}
