package Demo;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<KeyClass, ValueClass, Text, Text> 
{
	protected void map(KeyClass key, ValueClass value, Context context)
            throws java.io.IOException, InterruptedException 
	{
		Double amt=Double.parseDouble(value.getAmount().toString());
		String c=value.getCategory().toString().toUpperCase();
		if(amt>190 && c.equals("GAMES"))
		{
			Text cat=new Text(c+"\t"+amt);
			   context.write(key.getTid(),cat);
		}
	}
}
