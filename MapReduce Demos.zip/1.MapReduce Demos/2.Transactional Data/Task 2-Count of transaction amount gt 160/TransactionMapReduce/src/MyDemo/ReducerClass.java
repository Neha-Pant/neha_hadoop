package MyDemo;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class ReducerClass extends Reducer<Text,IntWritable,Text,IntWritable>
{
public void reduce(Text inkey,Iterable<IntWritable> invals,Context context) throws InterruptedException, IOException
{
    int count=0;
    for(IntWritable singleValue:invals)
    {
      count++;
    }
		context.write(new Text("->"),new IntWritable(count));
    }
}