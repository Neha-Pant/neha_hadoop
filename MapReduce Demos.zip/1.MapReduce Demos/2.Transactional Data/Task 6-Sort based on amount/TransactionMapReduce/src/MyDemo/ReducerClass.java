package MyDemo;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class ReducerClass extends Reducer<DoubleWritable,Text,Text,NullWritable>
{
public void reduce(DoubleWritable inkey,Iterable<Text> invals,Context context) throws InterruptedException, IOException
{
	String data="";
    for(Text singleValue:invals)
    {
      data=inkey+" "+singleValue;
    }
		context.write(new Text(data),null);

    }
}