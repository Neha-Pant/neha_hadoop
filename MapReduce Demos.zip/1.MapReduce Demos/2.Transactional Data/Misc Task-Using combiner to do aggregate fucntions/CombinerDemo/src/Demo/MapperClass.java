package Demo;

import java.io.IOException;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<LongWritable, Text,Text,Text>
{
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException 
    {
    	String line=value.toString();
        String[] lineparts=line.split(",");
        String amount=lineparts[3];
        String type=lineparts[8];
      		  context.write(new Text(type.toUpperCase()),new Text(amount));
      }


}
