package MyDemo;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class ReducerClass extends Reducer<Text,Text,Text,Text>
{
public void reduce(Text inkey,Iterable<Text> invals,Context context) throws InterruptedException, IOException
{
	for(Text data:invals)
				context.write(new Text(data),new Text(inkey));
    }
}