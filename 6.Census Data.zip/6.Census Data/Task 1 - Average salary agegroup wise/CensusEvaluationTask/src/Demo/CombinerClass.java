package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class CombinerClass extends Reducer<Text,Text,Text,Text>
{
public void reduce(Text inkey,Iterable<Text> invals,Context context) throws InterruptedException, IOException
{
	 Double sum=new Double(0);
	 Double min=new Double(0);
	 int c=1;
	Double max=new Double(0);
	Double avg=new Double(0);
    for(Text singleValue:invals)
    {
    	String d=singleValue.toString();
    	Double temp=Double.parseDouble(d);
      sum+=temp;
      if(max<temp)
      {
    	  max=temp;
      }
      if(min>temp)
      {
    	min=temp;  
      }
      c++;
    }
    avg=sum/c;
    String data="\n-----------\n| Count : "+c+" |\n| Minimum amount : "+min+" |\n| Maximum amount : "+max+" |\n| Sum : "+sum+" |\n| Average : "+avg+" |";
    context.write(inkey,new Text(data));
    }	
}
