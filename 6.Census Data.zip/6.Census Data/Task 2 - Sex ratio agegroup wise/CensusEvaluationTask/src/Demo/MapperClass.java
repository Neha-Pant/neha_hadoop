package Demo;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<LongWritable,Text,Text,Text>
{
	private Map<String, String> map = new HashMap<String, String>();
	@Override
	protected void setup(Context context) throws IOException, InterruptedException 
	{
		Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());		
	for (Path SinglePath : files) {
		if (SinglePath.getName().equals("agegroup.dat")) 
		{
			BufferedReader reader = new BufferedReader(new FileReader(SinglePath.toString()));
		String line="";
		while((line=reader.readLine())!=null)
		{
			String data[]=line.split("\\t");
			String age=data[0].trim();
			String cat=data[1].trim();
			map.put(age,cat);
		}
		reader.close();
		}
	}
	if (map.isEmpty()) 
	{
		throw new IOException("Unable To Load Data.");
	}
	}
	protected void map(LongWritable key, Text value, Mapper<LongWritable, Text, Text, Text>.Context context)
			throws IOException, InterruptedException 
	{
		String[] tData=value.toString().split(",");
		String[] temp=tData[0].split(":");
		String age=temp[1].trim();
		String[] temp1=tData[3].split(":");
		String gender=temp1[1].trim();
		String tcat=map.get(age);
//		String tdetails=tname+" has "+tstatus+"ed";
	//if(tname!=null)
		context.write(new Text(tcat), new Text(gender));
	}
}
