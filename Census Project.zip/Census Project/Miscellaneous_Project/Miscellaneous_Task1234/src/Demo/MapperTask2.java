package Demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperTask2 extends Mapper<MyKey,MyValue,Text,DoubleWritable>
{
	private Map<Integer, String> map = new HashMap<Integer, String>();
	@Override
	protected void setup(Context context) throws IOException, InterruptedException 
	{
		Path[] files = DistributedCache.getLocalCacheFiles(context.getConfiguration());		
	for (Path SinglePath : files) {
		//if (SinglePath.getName().equals("/user/cloudera/agegroup.dat")) 
		//{
			BufferedReader reader = new BufferedReader(new FileReader(SinglePath.toString()));
		String line="";
		while((line=reader.readLine())!=null)
		{
			String data[]=line.split("\\t");
			int age=Integer.parseInt(data[0].trim());
			String cat=data[1].trim();
			map.put(age,cat);
		}
		reader.close();
		//}
	}
	if (map.isEmpty()) 
	{
		throw new IOException("Unable To Load Agegroup Data .");
	}
	}
	protected void map(MyKey key,MyValue value,Context context) throws IOException, InterruptedException 
			{
		String gender=value.getGender().toString().trim();
		int age=Integer.parseInt(key.getAge().toString());
		String maritalStatus=value.getMaritalStatus().toString().trim();
		double tsal=Double.parseDouble(value.getIncome().toString())*12;
		String tcat=map.get(age);
			String data="\nAge group : "+tcat+"\tGender : "+gender+"\tMarital Status : "+maritalStatus+
					"\n=====================================================================================\n";
			context.write(new Text(data), new DoubleWritable(tsal));

		}

}
