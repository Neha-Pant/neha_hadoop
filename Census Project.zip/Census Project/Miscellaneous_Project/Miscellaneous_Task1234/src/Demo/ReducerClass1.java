package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerClass1 extends Reducer<Text,Text,Text,Text>
{

public void reduce(Text inkey,Iterable<Text> invals,Context context) throws InterruptedException, IOException
{
	int count=0;
	for(@SuppressWarnings("unused") Text x:invals)
	{
		count++;
	}
	String gender=context.getConfiguration().get("gender");
	int min=context.getConfiguration().getInt("min", 0);
	int max=context.getConfiguration().getInt("max", 0);
	context.write(new Text("Count of "+gender+"(s) in the age range of "+min+"-"+max+" "+inkey),new Text(""+count));
}
}
