package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperTask1 extends Mapper<MyKey,MyValue,Text,Text>
{
	protected void map(MyKey key,MyValue value,Context context) throws IOException, InterruptedException 
			{
		String gender=value.getGender().toString().trim();
		String userGender=context.getConfiguration().get("gender");
		int age=Integer.parseInt(key.getAge().toString().trim());
		String education=value.getEducation().toString().trim();
		int min=context.getConfiguration().getInt("min",0);
		int max=context.getConfiguration().getInt("max",0);
		if((age>=min) && (age<=max) && (gender.equals(userGender)))
			context.write(new Text(education), new Text(""));
		
		}
	}
