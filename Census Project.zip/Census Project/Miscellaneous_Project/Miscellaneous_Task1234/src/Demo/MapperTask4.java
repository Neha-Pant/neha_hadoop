package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperTask4 extends Mapper<MyKey,MyValue,Text,Text>
{
	protected void map(MyKey key,MyValue value,Context context) throws IOException, InterruptedException 
			{
		String citizenship=value.getCitizenship().toString().trim();
		String countryofbirth=value.getCountryOfBirth().toString().trim();
		if(citizenship.equals("Foreign born- U S citizen by naturalization"))
			context.write(new Text(countryofbirth), new Text(""));
		}
	}
