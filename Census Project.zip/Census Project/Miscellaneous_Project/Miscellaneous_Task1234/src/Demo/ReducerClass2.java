package Demo;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerClass2 extends Reducer<Text,DoubleWritable,Text,Text>
{

public void reduce(Text inkey,Iterable<DoubleWritable> invals,Context context) throws InterruptedException, IOException
{
	double inc=0.0;
	int c=0;
	double avg=0.0;
	for(DoubleWritable x:invals)
	{
		inc+=x.get();
		c++;
	}
	avg=inc/c;
	context.write(new Text(inkey),new Text("Average Income : "+avg));
}
}
