package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperTask3 extends Mapper<MyKey,MyValue,Text,Text>
{
	protected void map(MyKey key,MyValue value,Context context) throws IOException, InterruptedException 
			{
		String gender=value.getGender().toString().trim();
			String marital=value.getMaritalStatus().toString().trim();
		int age=Integer.parseInt(key.getAge().toString().trim());
		int mi=context.getConfiguration().getInt("min",18);
		int ma=context.getConfiguration().getInt("max",18);
		if((age>=mi) && (age<=ma) && (gender.equalsIgnoreCase("Female")) && ((marital.equals("Divorced")) || (marital.equals("Widowed"))))
		{
			context.write(new Text(marital), new Text(""));
		}
		}
	}
