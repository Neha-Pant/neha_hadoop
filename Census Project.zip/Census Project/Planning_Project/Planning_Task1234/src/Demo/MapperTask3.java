package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperTask3 extends Mapper<MyKey,MyValue,Text,Text>
{
	protected void map(MyKey key,MyValue value,Context context) throws IOException, InterruptedException 
			{
		String gender=value.getGender().toString().trim();
			context.write(new Text(gender), new Text(""));
		
		}
	}
