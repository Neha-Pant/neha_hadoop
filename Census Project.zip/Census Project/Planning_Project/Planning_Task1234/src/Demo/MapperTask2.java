package Demo;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperTask2 extends Mapper<MyKey,MyValue,Text,Text>
{
	protected void map(MyKey key,MyValue value,Context context) throws IOException, InterruptedException 
	{
		int tage=Integer.parseInt(key.getAge().toString());
		String gender=value.getGender().toString();
		int ea,ey;
		ea=context.getConfiguration().getInt("eligibleyear",0);
		ey=context.getConfiguration().getInt("cheackyear",0);
		tage=tage+ey;
		if(tage>=ea)
		{
			if(gender.equals(" Female"))
			{
		context.write(new Text("Female senior citizen(s) after "+ey+" year(s) : "), new Text("Passed"));
			}
			else
			{
		context.write(new Text("Male senior citizen(s) after "+ey+" year(s) : "), new Text("Passed"));
			}
		}
	}
}
