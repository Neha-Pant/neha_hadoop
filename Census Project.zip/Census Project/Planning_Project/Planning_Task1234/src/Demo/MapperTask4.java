package Demo;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperTask4 extends Mapper<MyKey,MyValue,Text,Text>
{
	protected void map(MyKey key,MyValue value,Context context) throws IOException, InterruptedException 
	{
		String status=value.getCitizenship().toString();
		int weeks=Integer.parseInt(value.getWeeksWorked().toString());
		if(weeks!=0)
		{
		if(status.contains(" Foreign"))
		{
		context.write(new Text("Immigrants :"), new Text("Passed"));
		}
		else
		{
			context.write(new Text("Citizens :"), new Text("Passed"));	
		}
		}
	}
}
