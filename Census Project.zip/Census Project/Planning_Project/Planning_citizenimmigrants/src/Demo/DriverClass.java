package Demo;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
public class DriverClass 
{
public static void main(String []arg) throws IOException, InterruptedException, ClassNotFoundException
{
	Configuration con=new Configuration();
	FileSystem hdfs = FileSystem.get(con);
	Job job=new Job(con,"Census demo");//throws IOException
	job.setJarByClass(DriverClass.class);
	job.setNumReduceTasks(1);
	job.setMapperClass(MapperClass.class);
	job.setReducerClass(ReducerClass.class);
	job.setMapOutputKeyClass(Text.class);
	job.setMapOutputValueClass(Text.class);
	Path newFolderPath = new Path(arg[1]);
	try
	{
	FileInputFormat.addInputPath(job,new Path(arg[0]));
	if (hdfs.exists(newFolderPath)) 
	{
		hdfs.delete(newFolderPath, true); 
	}
	}
	catch(Exception ex)
	{
		Logger ob=Logger.getLogger("errorlog");
		ob.log(Level.SEVERE,"Error found for : {0}",ex.getMessage());
	}
	FileOutputFormat.setOutputPath(job,newFolderPath);
	if(job.waitForCompletion(true))
	{
		hdfs.copyToLocalFile(new Path(arg[1]),new Path("/home/cloudera/"));
	}
}
}
