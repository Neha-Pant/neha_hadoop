package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerClass2 extends Reducer<Text,Text,Text,Text>
{

public void reduce(Text inkey,Iterable<Text> invals,Context context) throws InterruptedException, IOException
{
	int e=0,ue=0;
	for(Text x:invals)
	{
		int weeks=Integer.parseInt(x.toString().trim());
		if(weeks>0)
			e++;
		else
			ue++;
	}
	context.write(new Text(inkey),new Text("Employed : "+e+"\tUnemployed : "+ue));
}
}
