package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerClass1 extends Reducer<Text,Text,Text,Text>
{

public void reduce(Text inkey,Iterable<Text> invals,Context context) throws InterruptedException, IOException
{
	int m=0,f=0;
	for(Text x:invals)
	{
		String gender=x.toString();
		if(gender.equals("Male"))
			m++;
		else
			f++;
	}
	context.write(new Text(inkey),new Text("Male : "+m+"\tFemale : "+f));
}
}
