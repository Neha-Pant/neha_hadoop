package Demo;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.WritableComparable;

@SuppressWarnings("rawtypes")
public class MyKey implements WritableComparable 
{
	private Text age;
	
	public MyKey()
	{
		age=new Text("");
	}	
	public MyKey(Text ob)
	{
		age=ob;
	}
	
	@Override
	public void readFields(DataInput in) throws IOException {
		age.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		age.write(out);
	}

	@Override
	public int compareTo(Object o) {
		MyKey ob = (MyKey)o;
		int cmp = age.compareTo(ob.age);
				return cmp;
	}
	public Text getAge() {
		return age;
	}
	public void setAge(Text age) {
		this.age = age;
	}
}
