package Demo;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperTask1 extends Mapper<MyKey,MyValue,Text,Text>
{
	protected void map(MyKey key,MyValue value,Context context) throws IOException, InterruptedException 
			{
		String gender=value.getGender().toString().trim();
		String education=value.getEducation().toString().trim();
			String data=gender;
			context.write(new Text(education), new Text(data));
		
		}
	}
