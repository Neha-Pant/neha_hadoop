package Demo;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;

public class MyValue implements Writable 
{
	private Text Education,MaritalStatus,Gender,TaxFilerStatus,Income,Parents,CountryOfBirth,Citizenship,WeeksWorked;
	
	
	public MyValue() 
	{
		Education=new Text();
		MaritalStatus=new Text();
		Gender=new Text();
		TaxFilerStatus=new Text();
		Income=new Text();
		Parents=new Text();
		CountryOfBirth=new Text();
		Citizenship=new Text();
		WeeksWorked=new Text();
	}

	public MyValue(Text education, Text maritalStatus, Text gender,Text taxFilerStatus, Text income, Text parents,Text countryOfBirth, Text citizenship, Text weeksWorked) 
	{
		Education = education;
		MaritalStatus = maritalStatus;
		Gender = gender;
		TaxFilerStatus = taxFilerStatus;
		Income = income;
		Parents = parents;
		CountryOfBirth = countryOfBirth;
		Citizenship = citizenship;
		WeeksWorked = weeksWorked;
	}

	@Override
	public void readFields(DataInput in) throws IOException {
		Education.readFields(in);
		MaritalStatus.readFields(in);
		Gender.readFields(in);
		TaxFilerStatus.readFields(in);
		Income.readFields(in);
		Parents.readFields(in);
		CountryOfBirth.readFields(in);
		Citizenship.readFields(in);
		WeeksWorked.readFields(in);
	}

	@Override
	public void write(DataOutput out) throws IOException {
		Education.write(out);
		MaritalStatus.write(out);
		Gender.write(out);
		TaxFilerStatus.write(out);
		Income.write(out);
		Parents.write(out);
		CountryOfBirth.write(out);
		Citizenship.write(out);
		WeeksWorked.write(out);
	}

	public Text getEducation() {
		return Education;
	}

	public void setEducation(Text education) {
		Education = education;
	}

	public Text getMaritalStatus() {
		return MaritalStatus;
	}

	public void setMaritalStatus(Text maritalStatus) {
		MaritalStatus = maritalStatus;
	}

	public Text getGender() {
		return Gender;
	}

	public void setGender(Text gender) {
		Gender = gender;
	}

	public Text getTaxFilerStatus() {
		return TaxFilerStatus;
	}

	public void setTaxFilerStatus(Text taxFilerStatus) {
		TaxFilerStatus = taxFilerStatus;
	}

	public Text getIncome() {
		return Income;
	}

	public void setIncome(Text income) {
		Income = income;
	}

	public Text getParents() {
		return Parents;
	}

	public void setParents(Text parents) {
		Parents = parents;
	}

	public Text getCountryOfBirth() {
		return CountryOfBirth;
	}

	public void setCountryOfBirth(Text countryOfBirth) {
		CountryOfBirth = countryOfBirth;
	}

	public Text getCitizenship() {
		return Citizenship;
	}

	public void setCitizenship(Text citizenship) {
		Citizenship = citizenship;
	}

	public Text getWeeksWorked() {
		return WeeksWorked;
	}

	public void setWeeksWorked(Text weeksWorked) {
		WeeksWorked = weeksWorked;
	}
	

	
}
